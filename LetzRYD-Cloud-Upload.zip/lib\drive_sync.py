"""
Sync heavy dashboard data from Google Drive → local cache.

Local PC (G: Drive already synced): no-op, uses project folder.
Streamlit Cloud: if secrets have gcp_service_account + drive.root_folder_id,
downloads Uber/OLA/GPS/Rapido/Allocation into .data_cache/ (only when changed).

Secrets example (.streamlit/secrets.toml on Cloud):

[gcp_service_account]
type = "service_account"
project_id = "..."
private_key_id = "..."
private_key = "-----BEGIN PRIVATE KEY-----\\n...\\n-----END PRIVATE KEY-----\\n"
client_email = "dashboard@....iam.gserviceaccount.com"
client_id = "..."
auth_uri = "https://accounts.google.com/o/oauth2/auth"
token_uri = "https://oauth2.googleapis.com/token"
auth_provider_x509_cert_url = "https://www.googleapis.com/oauth2/v1/certs"
client_x509_cert_url = "..."

[drive]
# Folder ID of "AI Dashboard" on Drive (from folder URL)
root_folder_id = "1xxxxxxxxxxxxxxx"
# Optional: separate "Rapido Data" folder ID (Pan India files)
rapido_data_folder_id = ""
"""

from __future__ import annotations

import io
import json
import os
from pathlib import Path
from typing import Any

from lib.paths import code_root, data_root

CACHE_DIRNAME = ".data_cache"
META_NAME = ".drive_sync_meta.json"
SCOPES = ["https://www.googleapis.com/auth/drive.readonly"]

# Subfolders under AI Dashboard root to sync (name → relative path)
SYNC_CHILDREN = {
    "Uber": "Uber",
    "OLA": "OLA",
    "Ola": "OLA",
    "GPS": "GPS",
    "Rapido": "Rapido",
    "Vehicle Allocation Status": "Vehicle Allocation Status",
}

SKIP_NAME_PREFIXES = ("~$",)
SKIP_DIR_NAMES = {"output", ".cache", "__pycache__", ".git"}
ALLOW_SUFFIXES = {".csv", ".xlsx", ".xls"}


def drive_configured() -> bool:
    try:
        import streamlit as st

        drive = st.secrets.get("drive", {})
        gcp = st.secrets.get("gcp_service_account", {})
        return bool(drive.get("root_folder_id")) and bool(gcp.get("client_email"))
    except Exception:
        return False


def cache_dir() -> Path:
    return code_root() / CACHE_DIRNAME


def _secrets_dict() -> dict[str, Any]:
    import streamlit as st

    return {
        "drive": dict(st.secrets.get("drive", {})),
        "gcp": dict(st.secrets.get("gcp_service_account", {})),
    }


def _drive_service():
    from google.oauth2 import service_account
    from googleapiclient.discovery import build

    info = _secrets_dict()["gcp"]
    # st.secrets may expose AttrDict — normalize private_key newlines
    creds_info = {k: info[k] for k in info}
    if "private_key" in creds_info:
        creds_info["private_key"] = str(creds_info["private_key"]).replace("\\n", "\n")
    creds = service_account.Credentials.from_service_account_info(
        creds_info, scopes=SCOPES
    )
    return build("drive", "v3", credentials=creds, cache_discovery=False)


def _list_children(service, folder_id: str) -> list[dict]:
    items: list[dict] = []
    page_token = None
    while True:
        resp = (
            service.files()
            .list(
                q=f"'{folder_id}' in parents and trashed=false",
                spaces="drive",
                fields="nextPageToken, files(id, name, mimeType, size, modifiedTime)",
                pageSize=200,
                pageToken=page_token,
                supportsAllDrives=True,
                includeItemsFromAllDrives=True,
            )
            .execute()
        )
        items.extend(resp.get("files", []))
        page_token = resp.get("nextPageToken")
        if not page_token:
            break
    return items


def _is_folder(item: dict) -> bool:
    return item.get("mimeType") == "application/vnd.google-apps.folder"


def _should_skip_file(name: str) -> bool:
    lower = name.lower()
    if any(name.startswith(p) for p in SKIP_NAME_PREFIXES):
        return True
    suf = Path(name).suffix.lower()
    return suf not in ALLOW_SUFFIXES


def _walk_files(
    service, folder_id: str, rel: Path, out: list[tuple[dict, Path]]
) -> None:
    for item in _list_children(service, folder_id):
        name = item.get("name") or ""
        if _is_folder(item):
            if name.lower() in SKIP_DIR_NAMES:
                continue
            _walk_files(service, item["id"], rel / name, out)
        else:
            if _should_skip_file(name):
                continue
            out.append((item, rel / name))


def _load_meta(meta_path: Path) -> dict:
    if not meta_path.exists():
        return {}
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _save_meta(meta_path: Path, meta: dict) -> None:
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")


def _download_file(service, file_id: str, dest: Path) -> None:
    from googleapiclient.http import MediaIoBaseDownload

    dest.parent.mkdir(parents=True, exist_ok=True)
    request = service.files().get_media(fileId=file_id, supportsAllDrives=True)
    tmp = dest.with_suffix(dest.suffix + ".partial")
    with open(tmp, "wb") as fh:
        downloader = MediaIoBaseDownload(fh, request, chunksize=8 * 1024 * 1024)
        done = False
        while not done:
            _, done = downloader.next_chunk()
    tmp.replace(dest)


def sync_drive_data(*, force: bool = False) -> dict:
    """
    Pull Drive folders into .data_cache and set AI_DASHBOARD_DATA_ROOT.
    Returns status dict for UI.
    """
    if not drive_configured():
        os.environ.pop("AI_DASHBOARD_DATA_ROOT", None)
        return {
            "ok": True,
            "mode": "local",
            "message": "Drive secrets not set — using local folders",
            "files": 0,
            "downloaded": 0,
            "root": str(data_root()),
        }

    secrets = _secrets_dict()
    root_id = str(secrets["drive"].get("root_folder_id", "")).strip()
    rapido_extra = str(secrets["drive"].get("rapido_data_folder_id", "")).strip()

    dest_root = cache_dir()
    dest_root.mkdir(parents=True, exist_ok=True)
    meta_path = dest_root / META_NAME
    meta = {} if force else _load_meta(meta_path)
    service = _drive_service()

    # Map top-level children of AI Dashboard folder
    top = _list_children(service, root_id)
    by_name = { (i.get("name") or ""): i for i in top if _is_folder(i) }

    planned: list[tuple[dict, Path]] = []
    for drive_name, local_rel in SYNC_CHILDREN.items():
        item = by_name.get(drive_name)
        if not item:
            continue
        _walk_files(service, item["id"], Path(local_rel), planned)

    # Optional Rapido Data → Rapido/ (or Rapido/Pan India)
    if rapido_extra:
        _walk_files(service, rapido_extra, Path("Rapido") / "Pan India", planned)
    else:
        # Sibling-style: if root parent listing not available, try child "Rapido Data"
        rd = by_name.get("Rapido Data")
        if rd:
            _walk_files(service, rd["id"], Path("Rapido") / "Pan India", planned)

    downloaded = 0
    skipped = 0
    errors: list[str] = []

    for item, rel in planned:
        fid = item["id"]
        size = str(item.get("size") or "0")
        mtime = str(item.get("modifiedTime") or "")
        key = fid
        prev = meta.get(key, {})
        dest = dest_root / rel
        need = force or not dest.exists() or prev.get("size") != size or prev.get("modifiedTime") != mtime
        if not need:
            skipped += 1
            continue
        try:
            _download_file(service, fid, dest)
            meta[key] = {
                "name": item.get("name"),
                "path": str(rel).replace("\\", "/"),
                "size": size,
                "modifiedTime": mtime,
            }
            downloaded += 1
        except Exception as exc:  # noqa: BLE001 — surface in UI
            errors.append(f"{rel}: {exc}")

    _save_meta(meta_path, meta)
    os.environ["AI_DASHBOARD_DATA_ROOT"] = str(dest_root)

    return {
        "ok": len(errors) == 0,
        "mode": "drive",
        "message": "Synced from Google Drive" if downloaded or skipped else "No matching files on Drive",
        "files": len(planned),
        "downloaded": downloaded,
        "skipped": skipped,
        "errors": errors[:8],
        "root": str(dest_root),
        "client_email": secrets["gcp"].get("client_email", ""),
    }


def ensure_data_ready(*, force: bool = False, show_status: bool = True) -> dict:
    """
    Call once at app start.
    Local without secrets → local folders.
    Cloud with secrets → sync Drive cache.
    """
    if not drive_configured():
        os.environ.pop("AI_DASHBOARD_DATA_ROOT", None)
        return {
            "ok": True,
            "mode": "local",
            "message": "Local data folders",
            "files": 0,
            "downloaded": 0,
            "root": str(code_root()),
        }

    if show_status:
        try:
            import streamlit as st

            with st.status("Syncing data from Google Drive…", expanded=True) as status:
                st.write("Heavy files download only when changed (cached).")
                info = sync_drive_data(force=force)
                if info.get("errors"):
                    st.write("Some files failed:")
                    for e in info["errors"]:
                        st.write(f"- {e}")
                st.write(
                    f"Files seen: {info.get('files', 0)} · "
                    f"Downloaded: {info.get('downloaded', 0)} · "
                    f"Cached: {info.get('skipped', 0)}"
                )
                status.update(
                    label="Drive sync done" if info.get("ok") else "Drive sync finished with errors",
                    state="complete" if info.get("ok") else "error",
                )
                return info
        except Exception:
            pass
    return sync_drive_data(force=force)
